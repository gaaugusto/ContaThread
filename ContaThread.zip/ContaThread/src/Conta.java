public class Conta {
    
    private double saldo;
    
    public double getSaldo() {
        return saldo;
    }
    
    public void sacar(double valor) {
        double saldoAtualizado = this.saldo - valor;
        this.saldo = saldoAtualizado;
    }
    
    public void depositar(double valor) {
        double novoSaldo = this.saldo + valor;
        this.saldo = novoSaldo;
    }
}
